# GitHub upload notes

This archive is organized for direct publication to the repository root.

- `include/` contains public module interfaces.
- `src/` contains implementations.
- `tests/` contains the verification suite.
- Generated build logs and runtime chain-state files are intentionally excluded.
- The protocol constants are unchanged from the verified V20.7.x code; changing the protocol/network ID requires a separate consensus-version decision.
- This project is experimental and is not mainnet-ready.
